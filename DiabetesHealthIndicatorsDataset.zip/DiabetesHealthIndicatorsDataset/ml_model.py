import pickle
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.preprocessing import OrdinalEncoder


dataset = pd.read_csv('diabetes_012_health_indicators_BRFSS2015.csv', encoding='latin-1')
dataset = dataset.rename(columns=lambda x: x.strip().lower())
dataset.head()
dataset.drop(columns=['cholcheck','fruits','veggies','hvyalcoholconsump','anyhealthcare','nodocbccost','smoker','menthlth','sex',
                      'stroke','physactivity']
             ,inplace=True)
X = dataset.drop(['diabetes_012'], axis=1)
y = dataset['diabetes_012']

#sc = MinMaxScaler(feature_range=(0, 1))
#X_scaled = sc.fit_transform(X)

rf = RandomForestClassifier()
rf.fit(X, y)

pickle.dump(rf, open("ml_model.pkl", "wb"))
#pickle.dump(sc, open("scaler.pkl", "wb"))

