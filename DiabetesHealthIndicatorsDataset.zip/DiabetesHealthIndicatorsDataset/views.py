from django.shortcuts import render
import pickle


def home(request):
    return render(request, 'index.html')


def getPredictions(highbp, highchol, bmi,heartdiseaseorattack,
                            genhlth,physhlth,
                            diffwalk,age,education,income):
    model = pickle.load(open('ml_model.pkl', 'rb'))

    prediction = model.predict([[highbp, highchol, bmi,heartdiseaseorattack,
                            genhlth,physhlth,
                            diffwalk,age,education,income]])

    if prediction == 0:
        return 'no'
    elif prediction == 1:
        return 'prediabetes'
    else:
        return 'diabetes'


def result(request):
    highbp = int(request.GET['highbp'])
    highchol = int(request.GET['highchol'])
    bmi = int(request.GET['bmi'])
    heartdiseaseorattack = int(request.GET['heartdiseaseorattack'])
    genhlth = int(request.GET['genhlth'])
    physhlth = int(request.GET['physhlth'])
    diffwalk = int(request.GET['diffwalk'])
    age = int(request.GET['age'])
    education = int(request.GET['education'])
    income = int(request.GET['income'])

    result = getPredictions(highbp, highchol, bmi,heartdiseaseorattack
                            ,genhlth,physhlth,
                            diffwalk,age,education,income)

    return render(request, 'result.html', {'result': result})